from qgis.PyQt.QtWidgets import QAction, QMenu, QMessageBox, QInputDialog
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem,
    QgsGeometry,
    QgsPointXY,
    QgsSpatialIndex,
    edit
)
from PyQt5.QtWidgets import QMessageBox

import os

class MonPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.menu = None
        self.tool_button = None

    def initGui(self):
        # Créer l'action de menu principale
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.menu = QMenu("Fill", self.iface.mainWindow())
        self.menu.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")))


        actions = [
            ("FILL", self.remplir_attributs),
            ("ATTRIBUT 'NOM'", self.renommer_tous_les_noms),
            ("AGGC → ALIAS", self.attribuer_alias_depuis_chambres_ohh),
            ("PC en Point Techn", self.copier_pc_vers_pt),
            ("FONCTION CHAMBRE",self.remplir_fonction_chambre),
            ("TYPE CANAL",self.renommer_type_canal),
            
        ]

        for label, func in actions:
            action = QAction(label, self.iface.mainWindow())
            action.triggered.connect(func)
            self.menu.addAction(action)

        self.action_main = QAction(QIcon(icon_path), "AUTOMAT'INFRA", self.iface.mainWindow())
        self.action_main.setMenu(self.menu)

        self.iface.addPluginToMenu("OUTILS D'AUTOMATISATION INFRA", self.menu.menuAction())
        self.iface.addToolBarIcon(self.action_main)



    def unload(self):
            self.iface.removePluginMenu("AUTOMATISATION INFRA", self.menu.menuAction())
            self.iface.removeToolBarIcon(self.action_main)


#remplissage automatique des attributs (FILL)
    def remplir_attributs(self):
        attributs_cibles = ["REP", "PROJET", "NOM_SR", "ALIAS", "NOM_ZR", "ODF", "SRO", "OLT", "MSAN", "NOM_ZRO", "NOM_SPL"]

        champ_choisi, ok = QInputDialog.getItem(self.iface.mainWindow(), "Choix de l'attribut", "Sélectionner l'attribut à remplir :", attributs_cibles, 0, False)
        if not ok:
            QMessageBox.warning(None, "Annulé", "❌ Opération annulée.")
            return

        valeur, ok_val = QInputDialog.getText(self.iface.mainWindow(), "Valeur à insérer", f"Entrer la valeur pour '{champ_choisi}' :")
        if not ok_val or valeur.strip() == "":
            QMessageBox.warning(None, "Erreur", "❌ Aucune valeur saisie.")
            return

        total_modifiees = 0
        couches_modifiees = []
        erreurs = []

        for layer in QgsProject.instance().mapLayers().values():
            if not isinstance(layer, QgsVectorLayer):
                continue
            if champ_choisi not in [field.name() for field in layer.fields()]:
                continue

            if not layer.isEditable():
                if not layer.startEditing():
                    erreurs.append(f"❌ Impossible d'éditer la couche : {layer.name()}")
                    continue

            try:
                for feat in layer.getFeatures():
                    feat[champ_choisi] = valeur
                    layer.updateFeature(feat)
                    total_modifiees += 1

                if not layer.commitChanges():
                    erreurs.append(f"❌ Échec du commit : {layer.name()}")
                else:
                    couches_modifiees.append(layer.name())
            except Exception as e:
                layer.rollBack()
                erreurs.append(f"❌ Erreur dans {layer.name()} : {str(e)}")

        message = "===== RÉSULTAT =====\n"
        if couches_modifiees:
            message += f"✅ Champ '{champ_choisi}' rempli avec '{valeur}' dans {len(couches_modifiees)} couche(s) :\n"
            message += "\n".join(f" - {nom}" for nom in couches_modifiees)
            message += f"\n\n🔢 Total entités modifiées : {total_modifiees}\n"
        else:
            message += "⚠️ Aucune couche modifiée.\n"

        if erreurs:
            message += "\n===== ERREURS =====\n" + "\n".join(erreurs)

        QMessageBox.information(None, "Résultat", message)


#copie des PC en PT
    def copier_pc_vers_pt(self):
        try:
            layer_pc = QgsProject.instance().mapLayersByName("PC")[0]
            layer_pt = QgsProject.instance().mapLayersByName("Point Technique")[0]
            layer_pot = QgsProject.instance().mapLayersByName("Poteau")[0]

            common_fields_pt = [
                f.name() for f in layer_pc.fields()
                if f.name() in [g.name() for g in layer_pt.fields()] and f.name() != "TYPE"
            ]
            common_fields_pot = [
                f.name() for f in layer_pc.fields()
                if f.name() in [g.name() for g in layer_pot.fields()] and f.name() != "TYPE"
            ]

            layer_pt.startEditing()
            layer_pot.startEditing()

            for feature_pc in layer_pc.getFeatures():
                geom = feature_pc.geometry()
                type_pose_value = feature_pc["TYPE POSE"].lower() if feature_pc["TYPE POSE"] else ""

                if "poteau" in type_pose_value:
                    # Copier dans la couche Poteau
                    feat = QgsFeature(layer_pot.fields())
                    feat.setGeometry(geom)
                    for field_name in common_fields_pot:
                        feat[field_name] = feature_pc[field_name]
                    feat["TYPE"] = "poteau"
                    layer_pot.addFeature(feat)
                else:
                    # Copier dans Point Technique
                    if "façade" in type_pose_value:
                        type_val = "point façade"
                    elif "immeuble" in type_pose_value:
                        type_val = "point immeuble"
                    else:
                        type_val = None

                    feat = QgsFeature(layer_pt.fields())
                    feat.setGeometry(geom)
                    for field_name in common_fields_pt:
                        feat[field_name] = feature_pc[field_name]
                    feat["TYPE"] = type_val
                    layer_pt.addFeature(feat)

            layer_pt.commitChanges()
            layer_pot.commitChanges()
            QMessageBox.information(None, "Succès", "✅ Copie PC vers Point Technique et Poteau terminée avec TYPE défini.")

        except Exception as e:
            QMessageBox.critical(None, "Erreur", f"❌ Erreur : {str(e)}")



#remplissage des Alias avec une marge de 10m à la ronde
    def attribuer_alias_depuis_chambres_ohh(self):
        from qgis.core import (
            QgsProject, QgsSpatialIndex, QgsVectorLayer,
            QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry
        )
        from qgis.PyQt.QtWidgets import QFileDialog

        try:
            # 📁 Demander à l'utilisateur de sélectionner le fichier source
            chemin_fichier, _ = QFileDialog.getOpenFileName(
                None,
                "Sélectionner le fichier source contenant les alias",
                "",
                "Fichiers SIG (*.shp *.gpkg)"
            )
            if not chemin_fichier:
                QMessageBox.warning(None, "Annulé", "❌ Aucune sélection de fichier.")
                return

            # 📑 Charger le fichier en tant que couche
            layer_source = QgsVectorLayer(chemin_fichier, "Source Alias", "ogr")
            if not layer_source.isValid():
                QMessageBox.critical(None, "Erreur", "❌ Le fichier sélectionné est invalide.")
                return

            # 🧠 Demander à l'utilisateur quelle colonne contient les alias
            champs_disponibles = [f.name() for f in layer_source.fields()]
            champ_source, ok = QInputDialog.getItem(None, "Choix du champ Alias", "Sélectionner le champ contenant l'Alias :", champs_disponibles, 0, False)
            if not ok or not champ_source:
                QMessageBox.warning(None, "Annulé", "❌ Aucune colonne sélectionnée.")
                return

            # 📍 Cible = couche 'Chambre'
            couche_cible = QgsProject.instance().mapLayersByName("Chambre")
            if not couche_cible:
                QMessageBox.critical(None, "Erreur", "❌ La couche 'Chambre' n'est pas chargée dans QGIS.")
                return
            layer_cible = couche_cible[0]

            champ_cible = "Alias"
            valeur_defaut = "AGGC_IDQgis"
            rayon_buffer_m = 10

            # 🎯 Projections (conversion temporaire en métrique si besoin)
            crs_m = QgsCoordinateReferenceSystem("EPSG:32630")  # UTM 30N par exemple
            crs_src = QgsProject.instance().crs()
            transform_in = QgsCoordinateTransform(crs_src, crs_m, QgsProject.instance())

            # 🗺️ Index spatial sur la couche source
            index_spatial = QgsSpatialIndex()
            source_feats = {}

            for feat in layer_source.getFeatures():
                geom = QgsGeometry(feat.geometry())
                geom.transform(transform_in)
                feat_copy = QgsFeature(feat)
                feat_copy.setGeometry(geom)
                index_spatial.insertFeature(feat_copy)
                source_feats[feat.id()] = feat

            # ✏️ Préparation édition
            if not layer_cible.isEditable():
                if not layer_cible.startEditing():
                    QMessageBox.warning(None, "Erreur", "Impossible d'éditer la couche cible.")
                    return

            source_ids_utilises = set()
            compteur_valide = 0
            compteur_defaut = 0

            for feat in layer_cible.getFeatures():
                geom = QgsGeometry(feat.geometry())
                geom.transform(transform_in)
                buffer = geom.buffer(rayon_buffer_m, 8)

                voisins_ids = index_spatial.intersects(buffer.boundingBox())

                nearest_feat = None
                min_dist = float('inf')

                for vid in voisins_ids:
                    if vid in source_ids_utilises:
                        continue
                    candidate_geom = QgsGeometry(layer_source.getFeature(vid).geometry())
                    candidate_geom.transform(transform_in)
                    dist = geom.distance(candidate_geom)
                    if dist < min_dist:
                        nearest_feat = source_feats[vid]
                        min_dist = dist

                if nearest_feat:
                    valeur = nearest_feat[champ_source]
                    source_ids_utilises.add(nearest_feat.id())
                    compteur_valide += 1
                else:
                    valeur = valeur_defaut
                    compteur_defaut += 1

                feat[champ_cible] = valeur
                layer_cible.updateFeature(feat)

            layer_cible.commitChanges()

            message = (
                "✅ Mise à jour des Alias terminée.\n"
                f"✔️ {compteur_valide} chambre(s) ont reçu un Alias depuis le fichier sélectionné.\n"
                f"❌ {compteur_defaut} chambre(s) ont reçu la valeur par défaut : '{valeur_defaut}'."
            )
            QMessageBox.information(None, "Alias attribués", message)

        except Exception as e:
            QMessageBox.critical(None, "Erreur", f"Une erreur est survenue :\n{str(e)}")

    
    def renommer_tous_les_noms(self):
        from qgis.core import QgsProject, QgsGeometry
        from qgis.PyQt.QtWidgets import QInputDialog, QMessageBox

        # Définitions des préfixes et couches
        point_layers = {
            'Chambre': 'Cham_',
            'Point Technique': 'PT_',
            'Poteau': 'Pot_',
            'Batiment': 'Bati_'
        }
        line_layers = {
            'Tranchee': 'Tran_',
            'Canalisation': 'Canal_',
            'Support': 'Supp_'
        }
        connexion_layers_info = [
            ('Chambre', 'NOM'),
            ('Point Technique', 'NOM'),
            ('Poteau', 'NOM'),
            ('Site', 'NOM'),
            ('Point GC', 'id')
        ]

        def zero_pad(num, width=5):
            return str(num).zfill(width)

        def get_zr_value():
            sr_layers = QgsProject.instance().mapLayersByName("SR")
            if not sr_layers:
                QMessageBox.warning(None, "Erreur", "❌ Couche 'SR' introuvable. Opération annulée.")
                return None
            sr_layer = sr_layers[0]
            sr_feats = list(sr_layer.getFeatures())
            if not sr_feats:
                QMessageBox.warning(None, "Erreur", "❌ Aucune entité dans la couche 'SR'. Veuillez créer un SR et remplir la valeur de ZR")
                return None
            sr_feat = sr_feats[0]
            zr_value = sr_feat["NOM_ZR"]
            if not zr_value or str(zr_value).strip() == "":
                zr_value, ok = QInputDialog.getText(None, "Saisie NOM_ZR", "Entrez la valeur de NOM_ZR :")
                if not ok or zr_value.strip() == "":
                    QMessageBox.warning(None, "Erreur", "❌ Valeur NOM_ZR non fournie. Opération annulée.")
                    return None
                # Mise à jour dans la couche SR
                sr_layer.startEditing()
                idx = sr_layer.fields().indexFromName("NOM_ZR")
                sr_layer.changeAttributeValue(sr_feat.id(), idx, zr_value.strip())
                sr_layer.commitChanges()
            return str(zr_value).strip()

        def rename_points_with_nom_zr(zr_value):
            for layer_name, prefix in point_layers.items():
                layers = QgsProject.instance().mapLayersByName(layer_name)
                if not layers:
                    QMessageBox.warning(None, "Attention", f"⚠️ Couche '{layer_name}' introuvable.")
                    continue
                layer = layers[0]
                layer.startEditing()
                idx_nom = layer.fields().indexFromName('NOM')
                for feat in layer.getFeatures():
                    new_nom = f"{zr_value}-{prefix}{zero_pad(feat.id() + 1)}"
                    if idx_nom != -1:
                        layer.changeAttributeValue(feat.id(), idx_nom, new_nom)
                layer.commitChanges()

        # Charger couches connexion + champ pour rechercher nom point
        loaded_connexion_layers = []
        for name, champ in connexion_layers_info:
            layers = QgsProject.instance().mapLayersByName(name)
            if layers:
                loaded_connexion_layers.append((layers[0], champ))
            else:
                QMessageBox.warning(None, "Attention", f"⚠️ Couche de point '{name}' introuvable.")

        def get_connexion_name(point_geom):
            for layer, field in loaded_connexion_layers:
                for feat in layer.getFeatures():
                    if feat.geometry().contains(point_geom):
                        value = feat[field]
                        if value is None or str(value).strip() == '':
                            QMessageBox.warning(None, "Erreur", f"❌ Une entité de '{layer.name()}' n’a pas de valeur dans le champ '{field}'.")
                            layer.selectByIds([feat.id()])
                            return None
                        return str(value)
            return None

        def rename_lignes():
            for layer_name, prefix in line_layers.items():
                layers = QgsProject.instance().mapLayersByName(layer_name)
                if not layers:
                    QMessageBox.warning(None, "Attention", f"⚠️ Couche {layer_name} introuvable.")
                    continue
                layer = layers[0]
                erreurs = []
                layer.startEditing()
                idx_nom = layer.fields().indexFromName('NOM')
                for feat in layer.getFeatures():
                    geom = feat.geometry()
                    if geom.isMultipart():
                        line_points = geom.asMultiPolyline()[0]
                    else:
                        line_points = geom.asPolyline()
                    if not line_points or len(line_points) < 2:
                        continue
                    start_geom = QgsGeometry.fromPointXY(line_points[0])
                    end_geom = QgsGeometry.fromPointXY(line_points[-1])
                    nom_start = get_connexion_name(start_geom)
                    nom_end = get_connexion_name(end_geom)
                    if nom_start and nom_end:
                        if nom_start != nom_end:
                            new_nom = f"{prefix}{nom_start}-{nom_end}"
                            if idx_nom != -1:
                                layer.changeAttributeValue(feat.id(), idx_nom, new_nom)
                    else:
                        erreurs.append(feat.id())
                layer.commitChanges()
                if erreurs:
                    layer.selectByIds(erreurs)
                    QMessageBox.warning(None, "Erreur", f"❌ {len(erreurs)} entité(s) mal connectée(s) dans la couche '{layer.name()}' (voir sélection).")

        # Exécution complète
        zr_value = get_zr_value()
        if zr_value is None:
            return
        rename_points_with_nom_zr(zr_value)
        rename_lignes()
        QMessageBox.information(None, "Terminé", "Renommage des entités effectué avec succès.")


    def remplir_fonction_chambre(self):
        project = QgsProject.instance()
        chambre_layers = project.mapLayersByName("Chambre")
        canalisation_layers = project.mapLayersByName("Canalisation")

        if not chambre_layers or not canalisation_layers:
            QMessageBox.warning(None, "Erreur", "Couches 'Chambre' ou 'Canalisation' manquantes.")
            return

        chambre_layer = chambre_layers[0]
        canalisation_layer = canalisation_layers[0]

        index_canal = QgsSpatialIndex(canalisation_layer.getFeatures())

        # Vérifier que la couche est éditable
        if not chambre_layer.isEditable():
            chambre_layer.startEditing()

        count_updates = 0  # compteur de modifications

        for chambre in chambre_layer.getFeatures():
            # On saute les chambres de départ (fixes)
            if chambre["FONCTION"] == "Chambre de départ":
                continue

            geom_chambre = chambre.geometry()
            ids_near = index_canal.intersects(geom_chambre.buffer(0.5, 1).boundingBox())

            count_distribution = 0
            for fid in ids_near:
                canal_feat = canalisation_layer.getFeature(fid)
                if canal_feat["TYPE CANAL"] != "Distribution":
                    continue

                geom_line = canal_feat.geometry()
                if geom_line.isMultipart():
                    line_points = geom_line.asMultiPolyline()[0]
                else:
                    line_points = geom_line.asPolyline()

                if not line_points:
                    continue

                p1 = QgsPointXY(line_points[0])
                p2 = QgsPointXY(line_points[-1])

                if (geom_chambre.intersects(QgsGeometry.fromPointXY(p1)) or
                    geom_chambre.intersects(QgsGeometry.fromPointXY(p2))):
                    count_distribution += 1

            # Déterminer la fonction attendue
            if count_distribution == 0:
                fonction_attendue = None  # pas de distribution
            elif count_distribution >= 3:
                fonction_attendue = "Chambre de raccordement"
            elif count_distribution == 2:
                fonction_attendue = "Chambre de tirage"
            elif count_distribution == 1:
                fonction_attendue = "Chambre de Terminaison"
            else:
                fonction_attendue = None

            # Mise à jour si nécessaire
            if fonction_attendue and chambre["FONCTION"] != fonction_attendue:
                chambre_layer.changeAttributeValue(
                    chambre.id(),
                    chambre_layer.fields().indexFromName("FONCTION"),
                    fonction_attendue
                )
                count_updates += 1

        # Enregistrer les changements
        if chambre_layer.isEditable():
            chambre_layer.commitChanges()

        # Message final
        if count_updates > 0:
            QMessageBox.information(
                None,
                "Remplissage fonction chambre",
                f"✅ {count_updates} chambres ont été mises à jour automatiquement."
            )
        else:
            QMessageBox.information(
                None,
                "Remplissage fonction chambre",
                "ℹ️ Aucune chambre n'avait besoin d'être modifiée."
            )


    def renommer_type_canal(self):
        project = QgsProject.instance()
        canalisation_layers = project.mapLayersByName("Canalisation")
        chambre_layers = project.mapLayersByName("Chambre")
        pt_layers = project.mapLayersByName("Point Technique")
        poteau_layers = project.mapLayersByName("Poteau")

        if not canalisation_layers or not chambre_layers:
            QMessageBox.warning(None, "Erreur", "Couches 'Canalisation' ou 'Chambre' manquantes.")
            return

        canal_layer = canalisation_layers[0]
        chambre_layer = chambre_layers[0]
        pt_layer = pt_layers[0] if pt_layers else None
        poteau_layer = poteau_layers[0] if poteau_layers else None

        # Index spatial pour trouver les entités proches
        index_chambre = QgsSpatialIndex(chambre_layer.getFeatures())
        index_poteau = QgsSpatialIndex(poteau_layer.getFeatures()) if poteau_layer else None
        index_pt = QgsSpatialIndex(pt_layer.getFeatures()) if pt_layer else None

        # Vérifier que la couche est éditable
        if not canal_layer.isEditable():
            canal_layer.startEditing()

        count_updates = 0

        for canal in canal_layer.getFeatures():
            geom_line = canal.geometry()
            if geom_line.isMultipart():
                line_points = geom_line.asMultiPolyline()[0]
            else:
                line_points = geom_line.asPolyline()

            if not line_points:
                continue

            p1 = QgsPointXY(line_points[0])
            p2 = QgsPointXY(line_points[-1])

            # Chercher les entités connectées aux deux extrémités
            chambres_conn = []
            pts_conn = []
            poteaux_conn = []

            for fid in index_chambre.intersects(QgsGeometry.fromPointXY(p1).boundingBox()):
                feat = chambre_layer.getFeature(fid)
                if feat.geometry().intersects(QgsGeometry.fromPointXY(p1)):
                    chambres_conn.append(feat)
            for fid in index_chambre.intersects(QgsGeometry.fromPointXY(p2).boundingBox()):
                feat = chambre_layer.getFeature(fid)
                if feat.geometry().intersects(QgsGeometry.fromPointXY(p2)):
                    chambres_conn.append(feat)

            if pt_layer:
                for fid in index_pt.intersects(QgsGeometry.fromPointXY(p1).boundingBox()):
                    feat = pt_layer.getFeature(fid)
                    if feat.geometry().intersects(QgsGeometry.fromPointXY(p1)):
                        pts_conn.append(feat)
                for fid in index_pt.intersects(QgsGeometry.fromPointXY(p2).boundingBox()):
                    feat = pt_layer.getFeature(fid)
                    if feat.geometry().intersects(QgsGeometry.fromPointXY(p2)):
                        pts_conn.append(feat)

            if poteau_layer:
                for fid in index_poteau.intersects(QgsGeometry.fromPointXY(p1).boundingBox()):
                    feat = poteau_layer.getFeature(fid)
                    if feat.geometry().intersects(QgsGeometry.fromPointXY(p1)):
                        poteaux_conn.append(feat)
                for fid in index_poteau.intersects(QgsGeometry.fromPointXY(p2).boundingBox()):
                    feat = poteau_layer.getFeature(fid)
                    if feat.geometry().intersects(QgsGeometry.fromPointXY(p2)):
                        poteaux_conn.append(feat)

            # -------------------
            # LOGIQUE DE RÈGLES
            # -------------------
            if len(chambres_conn) == 2:
                type_canal = "Distribution"
            elif len(chambres_conn) == 1 and poteaux_conn:
                type_canal = "Adduction Aérien"
            elif len(chambres_conn) == 1 and any(pt_conn["TYPE"] == "Adduction Immeuble" for pt_conn in pts_conn):
                type_canal = "Adduction Immeuble"
            elif len(chambres_conn) == 1 and any(pt_conn["TYPE"] == "adduction façade" for pt_conn in pts_conn):
                type_canal = "Adduction Façade"
            elif len(chambres_conn) == 1 and any(pt_conn["TYPE"] == "adduction armoire" for pt_conn in pts_conn):
                type_canal = "Distribution"
            else:
                type_canal = canal["TYPE CANAL"]  # ne change pas si aucune règle

            # Mise à jour si nécessaire
            if canal["TYPE CANAL"] != type_canal:
                canal_layer.changeAttributeValue(
                    canal.id(),
                    canal_layer.fields().indexFromName("TYPE CANAL"),
                    type_canal
                )
                count_updates += 1

        # Commit des modifications
        if canal_layer.isEditable():
            canal_layer.commitChanges()

        QMessageBox.information(
            None,
            "Renommage TYPE CANAL",
            f"✅ {count_updates} canalisations ont été mises à jour automatiquement."
        )
